
/**
 *
 * @author Cheryl Ong
 */
public class Game {

    public static void main(String[] arg) {
        
        Card c1, c2;
        
        c1 = new Card(Rank.SIX, Suit.RED);
        c2 = new Card(Rank.FOUR, Suit.GREEN);
        
        system.out.println(c1.toString() + "\n" + c2.toString());
                       
}


    
}
