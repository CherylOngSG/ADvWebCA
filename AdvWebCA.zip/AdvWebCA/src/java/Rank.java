/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Cheryl Ong
 */
public enum Rank {
    ZERO(0, "Zero"), ONE(1, "One"), TWO(2, "Two"), THREE(3, "Three"), 
    FOUR(4, "Four"), FIVE(5, "Five"), SIX(6, "Six"), SEVEN(7, "Seven"), 
    EIGHT(8, "Eight"), NINE(9, "Nine"), PICK_TWO(+2, "Pick Two"), 
    REVERSE(-1, "REverse"), SKIP(+1, "Skip"), 
    WILD(00, "Wild"), WILD_FOUR(0000, "Wild Four"); 
    
    //Private Field
    private final int rankValue;
    private final String rankString;
    
    // Constructor   
    private Rank(int rankValue, String rankString){
        this.rankValue = rankValue;
        this.rankString = rankString;
    }
    
    //Public Methods
    public int getRank() {
        return rankValue;
    }
    public String printRank() {
        return rankString;
    }       
           
}
