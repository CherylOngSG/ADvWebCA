import java.util.ArrayList;
/**
 *
 * @author Cheryl Ong
 */
public class Hand {
    private ArrayList<Card> cards;
    //Constructor
    public Hand() {
        cards = new ArrayList<Card>();
    }
    public void clear() {
        cards.clear();
    }
    public void add(Card card) {
        cards.add(card);
    }
    public String gameComplete(){
        String str = "";
        for (Card c: cards) {
            str += c.toString();
        }
        return str;
    }
    public boolean give(Card card, Hand otherHand) {
        if (!cards.contains.(card)) {
            return false;
        }
        else {
            cards.remove(card);
            otherHand.add(card);
            return true;
        }
    }
}
