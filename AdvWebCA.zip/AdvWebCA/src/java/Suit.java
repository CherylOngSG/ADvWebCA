/*
 Creating Enum class to set color for the cards
 */

/**
 *
 * @author Cheryl Ong
 */
public enum Suit {
    YELLOW("Yellow"), 
    BLUE("Blue"), 
    GREEN("Green"), 
    RED("Red"), 
    WILD("Wild");
    
    private final String suitText;
    
    // Constructor
    private Suit(String suitText) {
        this.suitText = suitText;
    }
    //Public method
    public String printSuit(){
        return suitText;
    }
}


