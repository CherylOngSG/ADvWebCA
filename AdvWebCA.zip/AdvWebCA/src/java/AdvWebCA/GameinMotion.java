/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AdvWebCA;

import java.sql.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.sql.DataSource;
/**
 *
 * @author Cheryl Ong
 */
@Stateless
public class GameinMotion implements GameinMotionLocal {

@Stateless
//Default behaviour
//@TransactionAttribute(TransactionAttributeType.REQUIRED)

	@Resource(lookup = "jdbc/AdvWebCA_DB")
	private DataSource ds;

	@Resource SessionContext ctx;

	//Container managed transaction
	//@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public List<Player> getAll() {

		List<Player> players = new LinkedList<>();

		try (Connection conn = ds.getConnection()) {

			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select * from Players");

			while (rs.next())
				players.add( Player.populate(rs));

		} catch (SQLException ex) { 
			ex.printStackTrace();
		}

		return (players);

	}
        

    public PopulatingDeck(){
        map=new HashMap<Long,String>();
        finalDeck=new ArrayList<String>();
        mapDeck=new HashMap<String,Integer>();
        map.put(new Long(0), "blue");
        map.put(new Long(1), "green");
        map.put(new Long(2), "yellow");
        map.put(new Long(3), "red");
        generateDeck();
    }
    
      
    public static boolean cardDisplayCheck(){
        String localCardNumberDisplay=randCardNumber();
        if(!localCardNumberDisplay.startsWith("W")){
         checkCardKey=localCardNumberDisplay+" - " +randomColorGeneration();
        }
        else{
             checkCardKey=localCardNumberDisplay;
        }
        int cardCounter=0;
        if(!MapContainsValueFlag||!mapDeck.containsKey(checkCardKey)){
            mapDeck.put(checkCardKey, ++cardCounter);
            MapContainsValueFlag=true;
            return true;
    }
        if(checkCardKey.startsWith("0") && mapDeck.containsKey(checkCardKey)){
                return false;
             
        }
        if(checkCardKey.startsWith("W") && mapDeck.containsKey(checkCardKey)&& mapDeck.get(checkCardKey)<4){
            mapDeck.put(checkCardKey, mapDeck.get(checkCardKey)+1);
            return true;
         
    }
         
        if(mapDeck.containsKey(checkCardKey)){
               if(mapDeck.get(checkCardKey)<2){
                   mapDeck.put(checkCardKey, mapDeck.get(checkCardKey)+1);
                   return true;
               }
        }
        return false;
    }        
            else{
            returnString=String.valueOf(randomNum);
        return returnString;
        }
        return null;
        }
     
    public static boolean cardDisplayCheck(){
        String localCardNumberDisplay=randCardNumber();
        if(!localCardNumberDisplay.startsWith("W")){
         checkCardKey=localCardNumberDisplay+" - " +randomColorGeneration();
        }
        else{
             checkCardKey=localCardNumberDisplay;
        }
        int cardCounter=0;
        if(!MapContainsValueFlag||!mapDeck.containsKey(checkCardKey)){
            mapDeck.put(checkCardKey, ++cardCounter);
            MapContainsValueFlag=true;
            return true;
    }
        if(checkCardKey.startsWith("0") && mapDeck.containsKey(checkCardKey)){
                return false;
             
        }
        if(checkCardKey.startsWith("W") && mapDeck.containsKey(checkCardKey)&& mapDeck.get(checkCardKey)<4){
            mapDeck.put(checkCardKey, mapDeck.get(checkCardKey)+1);
            return true;        
    }
         
        if(mapDeck.containsKey(checkCardKey)){
               if(mapDeck.get(checkCardKey)<2){
                   mapDeck.put(checkCardKey, mapDeck.get(checkCardKey)+1);
                   return true;               
        }

    void performCardEffect(Game game) throws EmptyDeckException {
        switch (rank) {
            case SKIP:
                game.advanceToNextPlayer();
                game.advanceToNextPlayer();
                break;
            case REVERSE:
                game.reverseDirection();
                game.advanceToNextPlayer();
                break;
            case DRAW_TWO:
                nextPlayerDraw(game);
                nextPlayerDraw(game);
                game.advanceToNextPlayer();
                game.advanceToNextPlayer();
                break;
            case WILD_D4:
                nextPlayerDraw(game);
                nextPlayerDraw(game);
                nextPlayerDraw(game);
                nextPlayerDraw(game);
                game.advanceToNextPlayer();
                game.advanceToNextPlayer();
                break;
            default:
                game.advanceToNextPlayer();
                break;
        }
    }

    private void nextPlayerDraw(Game game) throws EmptyDeckException {
        int nextPlayer = game.getNextPlayer();
        Card drawnCard;
        try {
            drawnCard = game.deck.draw();
        }
        catch (EmptyDeckException e) {
            game.print("...deck exhausted, remixing...");
            game.deck.remix();
            drawnCard = game.deck.draw();
        }
        game.h[nextPlayer].addCard(drawnCard);
        //game.println("  Player #" + nextPlayer + " draws " + drawnCard + ".");
        game.println("  " + game.h[nextPlayer].getPlayerName() + " draws " +
            drawnCard + ".");
    }
    }

}
          
    
    
