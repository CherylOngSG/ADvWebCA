/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Cheryl Ong
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

public class generateCard {
    
}
  
private static Map<Long,String> map;
private static Map<String,Integer> mapDeck;
private static ArrayList <String> finalDeck;
private static boolean cardShow= false;
private static String checkCardKey;
private static boolean MapContainsValueFlag= false;
private static String cardValueReceived;
    
public generateCards(){
        map=new HashMap<Long,String>();
        finalDeck=new ArrayList<String>();
        mapDeck=new HashMap<String,Integer>();
        map.put(new Long(0), "blue");
        map.put(new Long(1), "green");
        map.put(new Long(2), "yellow");
        map.put(new Long(3), "red");
        generateDeck();
    }
private static String  randomColorGeneration(){
        long temp=Math.round(Math.random()*3);
            if(map.containsKey(temp)){
                return map.get(temp);
            }
            else{
                return null;
            }
}
        
    public static void main(String[] args) {
        // TODO Aut#o-generated method stub#
        System.out.println("You have drawn" + map.toString());
        GenerateCards generatingCard =new GenerateCards();
      for(int i=0;i<finalDeck.size();i++){
          System.out.println(finalDeck.get(i)+"  \n");
      } 
    }  
}
 

