/**
 *
 * @author Cheryl Ong
 */
public class Card {
    /**
    * @param args
    *  */
            //Create private felds
            
    private Suit suit;
    private Rank rank;
    private boolean isFaceUp;
    
    //Constructor
    
    public Card(Rank rank, Suit suit) {
            this.rank = rank;
            this.suit = suit;  
            isFaceUp = true;            
    }
    //Public methods
    
    public String getSuit(){
    return suit.printSuit();
    }

    public int getRank() {
    return rank.getRank();
    }
    public String toString() {
    String str = "";
    if (isFaceUp) {
        str += rank.printRank() + " of " + suit.printSuit();
    }
    else {   
        str = "Face Down.";
    }
    return str;
    
    }
  
}


    


