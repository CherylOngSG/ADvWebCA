
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Cheryl Ong
 */

@WebServlet("/newgame")
public class GenerateCardManager extends HttpServlet {

	@EJB private GameinMotion GameinMotionEJB;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
            
            int numPlayers = 0;
            numPlayers = getNumberOfPlayers();
            Player[] player = new Player[numPlayers];

            for(int i=0;i<5;i++){
            ho.shuffle();
        }

         
        // Initialize players
        for (int i=0;i<numPlayers;i++){
            player[i] = new Player();
        }

        for (int i=0;i<4;i++){
            for (int j=0;j<numPlayers;j++){
                player[j].setCard(Card.getCard(cardCounter++), i);
            }
        }

		//begin 
		List<Card> Cards = GameinMotionEJB.getAll();
		//end 

		JsonArrayBuilder arrBuilder = Json.createArrayBuilder();
		for (Card c: cards)
			arrBuilder.add(c.toJson());

		JsonArray cardsArr = arrBuilder.build();

		resp.setStatus(HttpServletResponse.SC_OK);
		resp.setContentType("application/json");
		try (PrintWriter pw = resp.getWriter()) {
			pw.print(cardsArr.toString());
		}

	}

	
	
}
