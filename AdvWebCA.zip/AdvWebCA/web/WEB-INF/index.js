$(function() {

	var rowTemple = Handlebars.compile($("#rowTemplate").html());
	var tbodyTemplate = Handlebars.compile($("#tbodyTemplate").html());

	$("#btnStart").on("click", function() {
		//Async
		var promise = $.getJSON("select");
		promise.done(function(result) { //200 - 
			var tbody = tbodyTemplate({ generateCard: result })
			$("#result").append(tbody);
			
		});
			
	});
});