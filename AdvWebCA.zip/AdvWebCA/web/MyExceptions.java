
import javax.ejb.ApplicationException;
import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Cheryl Ong
 */
import javax.ejb.ApplicationException;

@ApplicationException(rollback = true)
public class MyExceptions extends Exception {
	
  try {
    numPlayers = getNumberOfPlayers();
  } catch (HoldemUserException e) {
    System.out.println(e.getMessage());
  
  } catch (UNOIOException e) {
     System.err.println("Error: error trying to read input."); 
     System.exit(1); 
  }
} while (numPlayers = 0);
}

